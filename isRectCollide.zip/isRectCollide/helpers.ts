export const toRadians = (degrees: number) => (degrees * Math.PI) / 180;
export const toDegrees = (radians: number) => (radians * 180) / Math.PI;

// .1 - .3 > -0.19999999999999998
// fixFloat(.1 - .3) > -0.2
export const fixFloat = (
  number: number,
  precision = Math.log10(1 / Number.EPSILON)
) => (number ? parseFloat(number.toFixed(precision)) : 0);
