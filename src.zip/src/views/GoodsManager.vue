<template>
  <div class="goods-manager">商品管理</div>
</template>

<script>
export default {
  name: "goods-manager",
};
</script>

<style lang="less" scoped>
</style>