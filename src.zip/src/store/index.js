import Vue from "vue";
import Vuex from "vuex";
import createLogger from "vuex/dist/logger";
import api from "@/api";

Vue.use(Vuex);
let env = process.env.NODE_ENV,
  plugins = [];
if (env === "delelopment") plugins.push(createLogger());
const store = new Vuex.Store({
  state: {
    profile: null,
  },
  mutations: {
    setProfile(state, payload) {
      state.profile = payload;
    },
  },
  actions: {
    async setProfileAsync({ commit }) {
      let result;
      try {
        result = await api.profile();
        if (+result.resultCode !== 200) result.data = null;
     
        commit("setProfile", result.data);
      } catch (_) {}
      return result?.data;
    },
  },
  plugins,
});
export default store;
