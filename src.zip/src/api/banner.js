// 轮播图设置接口
import http from "./http";
// 获取轮播图列表
const queryCarouselsList = (pageNumber = 1, pageSize = 10) => {
  return http.get("/carousels", {
    params: {
      pageNumber,
      pageSize,
    },
  });
};
// 获取某条信息的详情
const queryCarouselsInfo = (carouselId = 0) =>
  http.get(`/carousels/${carouselId}`);
// 新增轮播图信息
const insertCarousels = (data) => http.post("/carousels", data);
// 修改轮播图信息
const updataCarousels = (data) => http.put("/carousels", data);
// 移除轮播图信息
const removeCarousels = (ids) => {
  if (ids == null) ids = [];
  if (!Array.isArray(ids)) ids = [ids];
  return http.delete("/carousels", {
    data: { ids },
  });
};
export default {
  queryCarouselsInfo,
  queryCarouselsList,
  insertCarousels,
  updataCarousels,
  removeCarousels,
};
