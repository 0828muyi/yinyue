<template>
  <div class="error-page">
    <el-empty description="页面不存在哦~">
      <el-button type="primary" size="small" @click="$router.push('/home')">回到首页</el-button>
    </el-empty>
  </div>
</template>

<script>
export default {
  name: "error-page",
};
</script>

<style lang="less" scoped>
</style>