// 通用接口管理 & 导出各板块接口
import http from "./http";
import banner from "./banner";
import hot from "./hot"

// 用户登录
const login = (userName, passwordMd5) => {
  return http.post("/adminUser/login", {
    userName,
    passwordMd5,
  });
};
// 获取登陆者信息
const profile = () => http.get("/adminUser/profile");
// 上传图片
const upload = (file) => {
  let fm = new FormData();
  fm.append("file", file);
  return http.post("/upload/file", fm);
};
// 获取动态路由
const router = () => {
  // 模拟当前用户，只具备这几项的权限
  const routes = [
    {
      path: "controlpanel",
      name: "controlpanel",
      meta: {
        title: "控制面板",
        role: "",
        icon: "el-icon-menu",
        submenu: false,
        level: 2,
      },
      component: () => import("@/views/ControlPanel.vue"),
    },
    {
      path: "classification",
      name: "classification",
      meta: {
        title: "分类管理",
        role: "XFP001",
        icon: "el-icon-tickets",
        submenu: false,
        level: 2,
      },
      component: () => import("@/views/ClassiFication.vue"),
    },

    {
      path: "bannersetting",
      name: "bannersetting",
      meta: {
        title: "轮播图设置",
        role: "XFP005",
        icon: "el-icon-picture-outline",
        submenu: true,
        level: 2,
      },
      component: () => import("@/views/Home/BannerSetting.vue"),
    },
    {
      path: "goodssetting",
      name: "goodssetting",
      meta: {
        title: "热销商品设置",
        role: "XFP006",
        icon: "el-icon-wallet",
        submenu: true,
        level: 2,
      },
      component: () => import("@/views/Home/GoodsSetting.vue"),
    },
  ];
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        resultCode: 200,
        data: routes,
      });
    }, Math.round(Math.random() * 500 + 500));
  });
};
export default {
  login,
  profile,
  upload,
  router,
  hot,
  banner,
};
