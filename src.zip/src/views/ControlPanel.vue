<template>
  <div class="control-panel">
    <!-- 页面准备绘图的画布（盒子）;设置ref 后期在JS中获取到画布 -->
    <div class="imgBox1" ref="imgBox1"></div>
    <div class="imgBox2" ref="imgBox2"  ></div>
  </div>
</template>

<script>
import * as echarts from "echarts";
export default {
  name: "control-panel",
  methods: {
    // 折线图
    drawImgOne() {
      let myChart = echarts.init(this.$refs.imgBox1);
      let opations = {
        title: {
          text: "折线图",
        },
        tooltip: {
          trigger: "axis",
          axisPointer: {
            type: "cross",
            label: {
              backgroundColor: "#6a7985",
            },
          },
        },
        legend: {
          data: ["Email", "Phone"],
        },

        xAxis: [
          {
            type: "category",
            boundaryGap: false,
            data: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
          },
        ],
        yAxis: [
          {
            type: "value",
          },
        ],
        series: [
          {
            name: "Email",
            type: "line",
            stack: "Total",
            areaStyle: {},
            emphasis: {
              focus: "series",
            },
            data: [120, 132, 101, 134, 90, 230, 210],
          },
          {
            name: "Phone",
            type: "line",
            stack: "Total",
            areaStyle: {},
            emphasis: {
              focus: "series",
            },
            data: [220, 182, 191, 234, 290, 330, 310],
          },
        ],
      };
      myChart.setOption(opations);
    },
    // 饼状图
    drawImgTwo() {
      let myChart = echarts.init(this.$refs.imgBox2);
      let opations = {
        legend: {
          top: "bottom",
        },

        series: [
          {
            name: "饼状图",
            type: "pie",
            radius: [50, 250],
            center: ["50%", "50%"],
            roseType: "area",
            itemStyle: {
              borderRadius: 8,
            },
            data: [
              { value: 40, name: "rose 1" },
              { value: 38, name: "rose 2" },
              { value: 32, name: "rose 3" },
              { value: 30, name: "rose 4" },
              { value: 28, name: "rose 5" },
              { value: 26, name: "rose 6" },
              { value: 22, name: "rose 7" },
              { value: 18, name: "rose 8" },
            ],
          },
        ],
      };

      myChart.setOption(opations);
    },
  },
  mounted() {
    // 必须保证可以获取到画布后再去绘制
    this.drawImgOne();
    this.drawImgTwo();
  },
};
</script>

<style lang="less" scoped>
// 画布必须设置宽高
.control-panel {
  padding: 10px;
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  div {
    box-sizing: border-box;
    width: 46%;
    height: 400px;
  }
}
</style>