import { Line, Vector } from ".";
import { toRadians } from "../helpers";

export default class Rect {
  center: Vector;
  size: Vector;
  theta: number;
  rgb: string;

  constructor({
    x = 0,
    y = 0,
    w = 10,
    h = 10,
    // 0 is Horizontal to right (following OX) - Rotate clockwise
    theta = null,
    angle = 0, // theta (rad) or angle (deg)
    rgb = "0,0,0",
  }) {
    this.center = new Vector({ x, y });
    this.size = new Vector({ x: w, y: h });
    this.theta = theta || toRadians(angle);
    this.rgb = rgb;
  }

  getAxis() {
    const OX = new Vector({ x: 1, y: 0 });
    const OY = new Vector({ x: 0, y: 1 });
    const RX = OX.rotate(this.theta);
    const RY = OY.rotate(this.theta);
    return [
      new Line({ ...this.center, dx: RX.x, dy: RX.y }),
      new Line({ ...this.center, dx: RY.x, dy: RY.y }),
    ];
  }

  getCorners() {
    const axis = this.getAxis();
    const RX = axis[0].direction.multiply(this.size.x / 2);
    const RY = axis[1].direction.multiply(this.size.y / 2);
    return [
      this.center.add(RX).add(RY),
      this.center.add(RX).add(RY.multiply(-1)),
      this.center.add(RX.multiply(-1)).add(RY.multiply(-1)),
      this.center.add(RX.multiply(-1)).add(RY),
    ];
  }
}
