<template>
  <div class="classi-fication">分类管理</div>
</template>

<script>
export default {
  name: "classi-fication",
};
</script>

<style lang="less" scoped>
</style>