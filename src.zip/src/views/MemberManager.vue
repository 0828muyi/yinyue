<template>
  <div class="member-manager">会员管理</div>
</template>

<script>
export default {
  name: "member-manager",
};
</script>

<style lang="less" scoped>
</style>