<template>
  <div class="recommend-setting">为你推荐</div>
</template>

<script>
export default {
  name: "recommend-setting",
};
</script>

<style lang="less" scoped>
</style>