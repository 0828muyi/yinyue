<template>
  <div class="product-setting">新品上线</div>
</template>

<script>
export default {
  name: "product-setting",
};
</script>

<style lang="less" scoped>
</style>