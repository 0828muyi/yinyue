// 构建路由表（必做：路由懒加载）
import Login from "@/views/Login.vue";
import Home from "@/views/Home.vue";

const routes = [
  {
    path: "/",
    redirect: "/home",
  },
  {
    path: "/home",
    name:"home",
    meta: {
      title: "首页",
      level: 1,
    },
    component: Home,
    children: [{ path: "",
    redirect: "/home/controlpanel",}],
  },
  {
    path: "/login",
    name: "login",
    meta: {
      title: "登录",
      level: 1,
    },
    component: Login,
  }
];
export default routes;
