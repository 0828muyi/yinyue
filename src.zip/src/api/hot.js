import http from "./http";
// 获取热销商品列表
const indexConfigsList = (pageNumber = 1, pageSize = 10, configType = 3) => {
  return http.get("/indexConfigs", {
    params: {
      pageNumber,
      pageSize,
      configType,
    },
  });
};
// 获取某条信息
const indexConfigsInfo = (configId = 0) => {
  return http.get(`/indexConfigs/${configId}`);
};
// 新增信息
const insertIndexConfigs = (data) => {
  return http.post("/indexConfigs", data);
};
// 修改信息
const updataIndexConfigs = (data) => {
  return http.put("/indexConfigs", data);
};
// 移除信息
const removeIndexConfigs = (ids) => {
  if (ids == null) ids = [];
  if (!Array.isArray(ids)) ids = [ids];
  return http.delete("/indexConfigs", {
    data: { ids },
  });
};
export default {
  indexConfigsList,
  indexConfigsInfo,
  insertIndexConfigs,
  removeIndexConfigs,
  updataIndexConfigs,
};
