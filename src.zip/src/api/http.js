import axios from "axios";
import { Message } from "element-ui";
import _ from "@/assets/utils";

const http = axios.create({
  baseURL: "/api",
  timeout: 60000,
});
http.interceptors.request.use((config) => {
  // 基于请求头把Token传递给服务器 :非登录接口&本地存储了Token
  let token = _.storage.get("tk");
  if (token && config.url !== "/adminUser/login") {
    config.headers["token"] = token;
  }
  return config;
});
http.interceptors.response.use(
  (response) => {
    return response.data;
  },
  (reason) => {
    Message.error("当前网络繁忙，请您稍后再试~");
    return Promise.reject(reason);
  }
);
export default http;
