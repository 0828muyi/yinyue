<template>
  <div class="goodsSetting">
    <!-- 操控区 -->
    <div class="header-box">
      <el-button
        type="primary"
        icon="el-icon-plus"
        size="small"
        @click="visible = true"
        >增加</el-button
      >
      <el-popconfirm title="确定要删除这些选中的数据吗？">
        <el-button
          type="danger"
          icon="el-icon-delete"
          size="small"
          slot="reference"
        >
          批量删除
        </el-button>
      </el-popconfirm>
    </div>
    <!-- 表格区 -->
    <el-table
      ref="multipleTable"
      :data="tableData"
      tooltip-effect="dark"
      style="width: 100%"
      @selection-change="handleSelectionChange"
    >
      <el-table-column type="selection" width="55"> </el-table-column>
      <el-table-column label="商品名称" width="120" prop="configName">
      </el-table-column>
      <el-table-column prop="redirectUrl" label="跳转链接" width="120">
      </el-table-column>
      <el-table-column prop="configRank" label="排序值" show-overflow-tooltip>
      </el-table-column>
      <el-table-column prop="goodsId" label="商品编号" show-overflow-tooltip>
      </el-table-column>
      <el-table-column prop="createTime" label="添加时间" show-overflow-tooltip>
      </el-table-column>
      <el-table-column prop="address" label="操作" show-overflow-tooltip>
        <el-link type="success" @click="triggerUpdate(row)">修改</el-link>
        <el-popconfirm title="这是一段内容确定删除吗？">
          <el-link type="primary" slot="reference">删除</el-link>
        </el-popconfirm>
      </el-table-column>
    </el-table>
    <!-- 分页区 -->
    <el-pagination
      background
      layout="sizes, prev, pager, next"
      :hide-on-single-page="false"
      :page-size.sync="pagination.pageSize"
      :total="pagination.total"
      :current-page.sync="pagination.pageNumber"
      @current-change="init"
      @size-change="init"
    ></el-pagination>
    <!-- 新增&&修改 -->
    <el-dialog
      title="添加商品"
      :visible="visible"
      :before-close="closeDialog"
      :close-on-click-modal="false"
      :close-on-press-escape="false"
    >
      <el-form :rules="rules" ref="formIns" :model="ruleForm">
        <el-form-item label="商品名称" prop="configName">
          <el-input v-model.trim="ruleForm.configName"></el-input>
        </el-form-item>
        <el-form-item label="跳转链接" prop="redirectUrl">
          <el-input v-model.trim="ruleForm.redirectUrl"></el-input>
        </el-form-item>
        <el-form-item label="商品编号" prop="goodsId">
          <el-input-number
            v-model="num"
            controls-position="right"
            @change="handleChange"
          ></el-input-number>
        </el-form-item>
        <el-form-item label="排序值" prop="configRank">
          <el-input-number
            v-model="num1"
            controls-position="right"
            @change="handleChange"
          ></el-input-number>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="closeDialog">取 消</el-button>
        <el-button type="primary" @click="submit">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import _ from "@/assets/utils";
export default {
  name: "goodsSetting",

  data() {
    const ckeckConfigName = (_, value, callback) => {
      if (value.length === 0) {
        callback(new Error("内容不能为空"));
        return;
      }
      let reg = /^[a-zA-Z0-9_-]{1,16}$/;
      if (reg.test(value)) {
        callback(new Error("请填写内容"));
        return;
      }
      callback();
    };
    return {
      num: [],
      num1: [],
      visible: false,

      tableData: [],
      tableLoading: false,
      pagination: {
        pageNumber: 1,
        pageSize: 10,
        total: 0,
      },
      ruleForm: {
        configId: 0,
        configName: "",
        configRank: 0,
        createTime: "",
        goodsId: 0,
        redirectUrl: "",
      },
      rules: {
        configName: {
          required: true,
          validator: ckeckConfigName,
          trigger: "blur",
        },
        redirectUrl: {
          required: true,
          validator: ckeckConfigName,
          trigger: "blur",
        },
        goodsId: { required: true, message: "编号不能为空", trigger: "blur" },
        configRank: {
          required: true,
          message: "排序值不能为空",
          trigger: "blur",
        },
      },
    };
  },
  methods: {
    handleSelectionChange(val) {
      this.multipleSelection = val;
    },
    handleChange(value) {
      console.log(value);
    },

    // 根据当前页&每页展示条数
    async init() {
      this.tableLoading = true;
      try {
        let { pageNumber, pageSize } = this.pagination;
        let { resultCode, data } = await this.$api.hot.indexConfigsList(
          pageNumber,
          pageSize
        );
        if (+resultCode === 200) {
          this.pagination.total = +data.totalCount;
          this.tableData = data.list;
        } else {
          this.pagination.total = 0;
          this.tableData = [];
        }
      } catch (_) {}
      this.tableLoading = false;
    },
    // 关闭弹窗
    closeDialog() {
      this.visible = false;
      this.ruleForm = {
        configId: 0,
        configName: "",
        configRank: 0,
        createTime: "",
        goodsId: 0,
        redirectUrl: "",
      };
      this.ruleForm.configId = 0;
    },
    async submit() {
      try {
        await this.$refs.formIns.validate();
        let { configName, configType, goodsId, redirectUrl, configRank } =
          this.ruleForm;
        let { resultCode } = await this.$api.hot.insertIndexConfigs(
          configName,
          configType,
          goodsId,
          redirectUrl,
          configRank
        );
        if (+resultCode === 200) {
          this.$message.success("恭喜你，操作成功");
          this.closeDialog();
          this.init();
          console.log(data);
          return;
        } else {
          this.$message.error("操作失败，请稍后再试");
        }
      } catch (_) {}
    },
  },

  created() {
    this.init();
  },
};
</script>

<style lang="less" scoped>
.el-dialog__wrapper {
  width: 50%;
  margin: 0 auto;
}
/deep/.el-form-item__content {
  display: flex;
}
</style>