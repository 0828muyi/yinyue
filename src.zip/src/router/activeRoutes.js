/* 动态路由的处理:从服务器获取，增加到路由表中 */
import api from "@/api";
export default async function activeRoutes(router) {
  try {
    let currentList = router.getRoutes();

    // 获取二级动态路由，增加到home中
    let { resultCode, data } = await api.router();
    if (+resultCode !== 200) return;
    data.forEach((route) => {
      if (currentList.some((item) => item.name === route.name)) return;
      router.addRoute("home", route);
    });

    // 增加404到一级路由中
    if (currentList.some((item) => item.name === "error")) return;
    router.addRoute({
      path: "*",
      name: "error",
      meta: {
        title: "404",
        level: 1,
      },
      component: () => import("@/views/ErrorPage.vue"),
    });
  } catch (_) {}
}
