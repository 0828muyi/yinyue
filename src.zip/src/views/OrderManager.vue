<template>
  <div class="order-manager">订单管理</div>
</template>

<script>
export default {
  name: "order-manager",
};
</script>

<style lang="less" scoped>
</style>