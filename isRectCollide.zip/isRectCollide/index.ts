import { Rect } from ".";
import { Vector } from "./utils";

export * from "./helpers";
export * from "./utils";

export const isRectCollide = (
  rectA: Rect | { x: number; y: number; w: number; h: number; angle: number },
  rectB: Rect | { x: number; y: number; w: number; h: number; angle: number }
) => {
  const rA = rectA instanceof Rect ? rectA : new Rect(rectA);
  const rB = rectB instanceof Rect ? rectB : new Rect(rectB);
  return (
    isProjectionCollide({ rect: rA, onRect: rB }) &&
    isProjectionCollide({ rect: rB, onRect: rA })
  );
};

type Futher = {
  signedDistance: number;
  corner: Vector;
  projected: Vector;
};

const isProjectionCollide = ({
  rect,
  onRect,
}: {
  rect: Rect;
  onRect: Rect;
}) => {
  const lines = onRect.getAxis();
  const corners = rect.getCorners();

  let isCollide = true;

  lines.forEach((line, dimension) => {
    let futhers: { min: null | Futher; max: null | Futher } = {
      min: null,
      max: null,
    };
    // Size of onRect half size on line direction
    const rectHalfSize = (dimension === 0 ? onRect.size.x : onRect.size.y) / 2;
    corners.forEach((corner) => {
      const projected = corner.project(line);
      const CP = projected.minus(onRect.center);
      // Sign: Same directon of OnRect axis : true.
      const sign = CP.x * line.direction.x + CP.y * line.direction.y > 0;
      const signedDistance = CP.magnitude * (sign ? 1 : -1);

      if (!futhers.min || futhers.min.signedDistance > signedDistance) {
        futhers.min = { signedDistance, corner, projected };
      }
      if (!futhers.max || futhers.max.signedDistance < signedDistance) {
        futhers.max = { signedDistance, corner, projected };
      }
    });

    if (
      futhers.min &&
      futhers.max &&
      !(
        (futhers.min.signedDistance < 0 && futhers.max.signedDistance > 0) ||
        Math.abs(futhers.min.signedDistance) < rectHalfSize ||
        Math.abs(futhers.max.signedDistance) < rectHalfSize
      )
    ) {
      isCollide = false;
    }
  });
  return isCollide;
};
